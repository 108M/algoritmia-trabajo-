#include<ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include "colaEnteros.h"
int main(){
	tipoCola c;
    char nombre [50], basura,anterior,clase [2];
    int a,i,aux,elem;
    
    jugador primero;
    int t[8];
    FILE *f, *g;
    
    
    i = -1;
    nuevaCola(&c);
    
    printf( "Introduzca el nombre del fichero a leer: \n");
    scanf (" %s", nombre);
    f=fopen(nombre,"r");
    
    while (!feof(f))
    {
        if (fscanf (f,"%d",&a) == 1 && basura == ','){
            aux = a;
            i = i + 1;
           t[i] = aux ;
           printf("%d ",t[i]);
            if ( i == 8){
               encolar(&c,t,clase);
               i = -1;
            }
            
        }else{
            anterior = basura;
            basura=fgetc(f);
            
            if (anterior == 'G' && basura == 'K') {
                printf("leo GK");
                clase [0] = 'G';
                clase [1] = 'K';
            }
            else if(anterior == 'D' && basura == 'F') {
                printf("leo DF");
                 clase [0] = 'D';
                 clase [1] = 'F';
            }
            else if (anterior == 'M' && basura == 'F') {
                printf("leo MF");
                 clase [0] = 'M';
                 clase [1] = 'F';
            }
            else if(anterior == 'F' && basura == 'W') {
                printf("leo FW");
                 clase [0] = 'F';
                 clase [1] = 'W';
            }
        }
        
        
                
        }
        
        printf("\n");
        primero = frente (c);
        fclose;
        printf("imprimo primero \n");
        printf ("%d", primero.FP);
        printf (" %c" " %c", primero.clase[0],primero.clase[1]);
        desencolar(&c);
        primero = frente (c);
        printf("\n");
        printf("imprimo 2 \n");
        printf ("%d", primero.FP);
        printf (" %c" " %c", primero.clase[0],primero.clase[1]);

    
    
    
  

    return 0;
}
