#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "normalizar.h"

tipoCola normalizar (tipoCola c,tipoMaxMin mm ){
	tipoCola cn;
    nuevaCola(&cn);
    
    while(!esNulaCola(c)){
        //jugador
        jugador jg;
        jg = frente (c);
        desencolar(&c);
        
        //normalizar jugador
        jg.FP = (jg.FP - devuelveMinimo(0, mm))/(devuelveMaximo(0, mm)- devuelveMinimo(0, mm));
        jg.TP = (jg.TP - devuelveMinimo(1, mm))/(devuelveMaximo(1, mm)- devuelveMinimo(1, mm));
        jg.Patada = (jg.Patada - devuelveMinimo(2, mm))/(devuelveMaximo(2, mm)- devuelveMinimo(2, mm));
        jg.Cuerpo = (jg.Cuerpo - devuelveMinimo(3, mm))/(devuelveMaximo(3, mm)- devuelveMinimo(3, mm));
        jg.Control = (jg.Control - devuelveMinimo(4, mm))/(devuelveMaximo(4, mm)- devuelveMinimo(4, mm));
        jg.Guardia = (jg.Guardia - devuelveMinimo(5, mm))/(devuelveMaximo(5, mm)- devuelveMinimo(5, mm));
        jg.Velocidad = (jg.Velocidad - devuelveMinimo(6, mm))/(devuelveMaximo(6, mm)- devuelveMinimo(6, mm));
        jg.Estamina = (jg.Estamina - devuelveMinimo(7, mm))/(devuelveMaximo(7, mm)- devuelveMinimo(7, mm));
        jg.Valor = (jg.Valor - devuelveMinimo(8, mm))/(devuelveMaximo(8, mm)- devuelveMinimo(8, mm));
        
        //encolo normalizado
        encolarJugador(&cn, jg);
    }
    return cn;
}
