#include "colaEnteros.h"
#include "maxMin.h"

tipoCola normalizar (tipoCola c, tipoMaxMin mm);


