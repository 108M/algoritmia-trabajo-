#include <math.h>


typedef struct Vecino{
    float distancia;
    char clase[10];
     
}vecino;

tipoCola normalizar (tipoCola c, tipoMaxMin mm);

int precision (tipoCola cn, jugador jg);
int precisionk(tipoCola ,int , jugador );
vecino kdistancias (tipoCola cn, int k, vecino vec [k]);




