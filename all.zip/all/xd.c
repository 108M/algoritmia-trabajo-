#include<ctype.h>
#include <stdlib.h>
#include <stdio.h>

#include "colaEnteros.h"
#include "maxMin.h"

int main(){
    
    //LEER PARA OBTENER LOS JUGADORES
    char nombre [50], basura,anterior,clase [2];
    int a,i,aux,elem;
    
    jugador primero;
    float t[9];
    FILE *f, *g;
    
    
    i = -1;
    
    tipoCola c;
    nuevaCola(&c);
    
    printf( "Introduzca el nombre del fichero a leer: \n");
    scanf (" %s", nombre);
    f=fopen(nombre,"r");
    printf("Leyendo jugadores...\n");
    
    while (!feof(f))
    {
        if (fscanf (f,"%d",&a) == 1 && basura == ','){
            aux = a;
            i = i + 1;
           t[i] = aux ;
           //printf("%f ",t[i]);
            if ( i == 8){
               encolar(&c,t,clase);
               i = -1;
            }
            
        }else{
            anterior = basura;
            basura=fgetc(f);
            
            if (anterior == 'G' && basura == 'K') {
                //printf("leo GK");
                clase [0] = 'G';
                clase [1] = 'K';
            }
            else if(anterior == 'D' && basura == 'F') {
                //printf("leo DF");
                 clase [0] = 'D';
                 clase [1] = 'F';
            }
            else if (anterior == 'M' && basura == 'F') {
                //printf("leo MF");
                 clase [0] = 'M';
                 clase [1] = 'F';
            }
            else if(anterior == 'F' && basura == 'W') {
                //printf("leo FW");
                 clase [0] = 'F';
                 clase [1] = 'W';
            }
        }
        
        
                
        }
        
        printf("\n");
        /*primero = frente (c);
        fclose;
        printf("imprimo primero \n");
        printf ("%d", primero.FP);
        printf (" %c" " %c", primero.clase[0],primero.clase[1]);
        desencolar(&c);
        primero = frente (c);
        printf("\n");
        printf("imprimo 2 \n");
        printf ("%d", primero.FP);
        printf (" %c" " %c", primero.clase[0],primero.clase[1]);*/

    //LEER PARA OBTERNER LOS MAXIMOS Y MINIMOS

    //maxmin
    tipoMaxMin mm;
    nuevoMm(&mm);
    
    int j = 1;
    
    printf( "Introduzca el nombre del fichero a leer: \n");
    scanf (" %s", nombre);
    printf("Obteniendo maximos y minimos...\n");
    //abrir fichero
    f=fopen(nombre,"r");
    
    while (!feof(f))
    {
        if (fscanf (f,"%d",&a) == 1 && basura == ','){
            aux = a;
            i = i + 1;
            
            t[i] = aux;
           //printf("%d ",t[i]);
            if ( i == 8){
                if (j == 1) {
                    //iniciar maxmin con los primeros valores
                    iniciarMm(&mm, t);
                    
                    j = 2;
                    i = -1;
                }
                else {
					//printf("asdf");
                    compararMmYt(&mm, t);
                    i = -1;
                }
            }
            
        }else{
            basura=fgetc(f);   
        }
        
        //printf("\n");
        fclose;
        
    }
    //muestra los maximos y minimos
    mostrarMm(mm);
    
    //APLICAR NORMALIZACION
    tipoCola cn; //cola normalizada 
    nuevaCola(&cn);
    printf("ª\n");
    
    while(!esNulaCola(c)){
        //jugador
        jugador jg;
        jg = frente (c);
        desencolar(&c);
        
        //normalizar jugador
        jg.FP = (jg.FP - devuelveMinimo(0, mm))/(devuelveMaximo(0, mm)- devuelveMinimo(0, mm));
        printf("FP es %f\n", jg.FP);
        //jg.FP = (jg.FP - devuelveMinimo(0, mm))/(devuelveMaximo(0, mm)- devuelveMinimo(0, mm));
        
        //encolo normalizado
        encolarJugador(&cn, jg);
    }
    jugador p;
    p = frente(cn);
    printf ("El FP normalizado es %f\n", p.FP);
    printf ("El TP normalizado es %f y Patada %f\n", p.TP, p.Patada);
    printf("\n");

    return 0;
}
