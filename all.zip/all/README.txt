Se proporciona un make para facilitar la compilacion.
Aun hya bugs sin solucionar.
