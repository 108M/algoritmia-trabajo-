#include <math.h>

jugador crearjugador ();
tipoCola normalizar (tipoCola cn, tipoCola c, tipoMaxMin mm);
float calcular_distancia (tipoCola cn);


