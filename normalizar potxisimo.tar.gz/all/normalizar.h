


tipoCola normalizar (tipoCola cn, tipoCola c, tipoMaxMin mm);


