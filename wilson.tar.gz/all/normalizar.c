#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include "colaEnteros.h"
#include "maxMin.h"
#include <string.h>
#include "normalizar.h"


tipoCola normalizar (tipoCola c,tipoMaxMin mm ){
	tipoCola cn;
    nuevaCola(&cn);
    
    while(!esNulaCola(c)){
        //jugador
        jugador jg;
        jg = frente(c);
        desencolar(&c);
        
        //normalizar jugador
        setFP(&jg, (getFP(jg) - devuelveMinimo(0, mm))/(devuelveMaximo(0, mm)- devuelveMinimo(0, mm)));
        //jg.FP = (jg.FP - devuelveMinimo(0, mm))/(devuelveMaximo(0, mm)- devuelveMinimo(0, mm));
        setTP(&jg, (getTP(jg) - devuelveMinimo(1, mm))/(devuelveMaximo(1, mm)- devuelveMinimo(1, mm)));
        //jg.TP = (jg.TP - devuelveMinimo(1, mm))/(devuelveMaximo(1, mm)- devuelveMinimo(1, mm));
        setPatada(&jg, (getPatada(jg) - devuelveMinimo(2, mm))/(devuelveMaximo(2, mm)- devuelveMinimo(2, mm)));
        //jg.Patada = (jg.Patada - devuelveMinimo(2, mm))/(devuelveMaximo(2, mm)- devuelveMinimo(2, mm));
        setCuerpo(&jg, (getCuerpo(jg) - devuelveMinimo(3, mm))/(devuelveMaximo(3, mm)- devuelveMinimo(3, mm)));
        //jg.Cuerpo = (jg.Cuerpo - devuelveMinimo(3, mm))/(devuelveMaximo(3, mm)- devuelveMinimo(3, mm));
        setControl(&jg, (getControl(jg) - devuelveMinimo(4, mm))/(devuelveMaximo(4, mm)- devuelveMinimo(4, mm)));
        //jg.Control = (jg.Control - devuelveMinimo(4, mm))/(devuelveMaximo(4, mm)- devuelveMinimo(4, mm));
        setGuardia(&jg, (getGuardia(jg) - devuelveMinimo(5, mm))/(devuelveMaximo(5, mm)- devuelveMinimo(5, mm)));
        //jg.Guardia = (jg.Guardia - devuelveMinimo(5, mm))/(devuelveMaximo(5, mm)- devuelveMinimo(5, mm));
        setVelocidad(&jg, (getVelocidad(jg) - devuelveMinimo(6, mm))/(devuelveMaximo(6, mm)- devuelveMinimo(6, mm)));
        //jg.Velocidad = (jg.Velocidad - devuelveMinimo(6, mm))/(devuelveMaximo(6, mm)- devuelveMinimo(6, mm));
        setEstamina(&jg, (getEstamina(jg) - devuelveMinimo(7, mm))/(devuelveMaximo(7, mm)- devuelveMinimo(7, mm)));
        //jg.Estamina = (jg.Estamina - devuelveMinimo(7, mm))/(devuelveMaximo(7, mm)- devuelveMinimo(7, mm));
        setValor(&jg, (getValor(jg) - devuelveMinimo(8, mm))/(devuelveMaximo(8, mm)- devuelveMinimo(8, mm)));
        //jg.Valor = (jg.Valor - devuelveMinimo(8, mm))/(devuelveMaximo(8, mm)- devuelveMinimo(8, mm));
        
        
        //encolo normalizado
        encolarJugador(&cn, jg);
    }
   return cn;
	
}


int precision (tipoCola cn, jugador jg){
	
	int verdadero = 0;
	float sum = 0.0;
	float distancia = 0.0;
	float minimo = 1000.0;
	float distancia_atributo[9];
    
	//tipoCola cn;
	//cn = aux_cola;
	
    while(!esNulaCola(cn)){
        jugador jgfrente = frente(cn);
        
        distancia_atributo[0] = getFP(jgfrente) - getFP(jg);
        distancia_atributo[1] = getTP(jgfrente) - getTP(jg);
        distancia_atributo[2] = getPatada(jgfrente) - getPatada(jg);
        distancia_atributo[3] = getCuerpo(jgfrente) - getCuerpo(jg);
        distancia_atributo[4] = getControl(jgfrente) - getControl(jg);
        distancia_atributo[5] = getGuardia(jgfrente) - getGuardia(jg);
        distancia_atributo[6] = getVelocidad(jgfrente) - getVelocidad(jg);
        distancia_atributo[7] = getEstamina(jgfrente) - getEstamina(jg);
        distancia_atributo[8] = getValor(jgfrente) - getValor(jg);
        
        if (strcmp(getSupertecnica(jgfrente),getSupertecnica(jg)) == 0){
            distancia_atributo[9] = 0;
        }else{
            distancia_atributo[9] = 1;
        }
        
        for (int i = 0; i <10; i++){
            sum = sum + pow(distancia_atributo[i],2.0);
        }

        distancia = sqrt(sum);
        sum = 0.0;
        
        if (distancia != 0){
            if (minimo >= distancia){
                minimo = distancia;
                if (strcmp(getClase(jg), getClase(jgfrente)) == 0){
                    verdadero = 1;
                    
                }else{
					
                    verdadero = 0;
                    
                }
            }
        }
        
        avanzaSigCola(&cn);
    }
    
	return verdadero;
}

vecino kdistancias (tipoCola cn,jugador jg, int k, vecino vec[k]){
	
	int pos = 0; //pos va a guardar la posicion del mayor numero en los vecinos
	
	int rellenar = 0; // esto va a servir para rellenar K veces los vecinos
	float sum = 0.0;
	float distancia = 0.0;
	float minimo = 1000.0;
	float distancia_atributo [9];
	float max = 0.0; // va a ser la distancia mas grande de los k vecinos
	
	
	
	while(!esNulaCola(cn)){
		jugador jgfrente = frente(cn);
    
        
        distancia_atributo[0] = getFP(jgfrente) - getFP(jg);
        distancia_atributo[1] = getTP(jgfrente) - getTP(jg);
        distancia_atributo[2] = getPatada(jgfrente) - getPatada(jg);
        distancia_atributo[3] = getCuerpo(jgfrente) - getCuerpo(jg);
        distancia_atributo[4] = getControl(jgfrente) - getControl(jg);
        distancia_atributo[5] = getGuardia(jgfrente) - getGuardia(jg);
        distancia_atributo[6] = getVelocidad(jgfrente) - getVelocidad(jg);
        distancia_atributo[7] = getEstamina(jgfrente) - getEstamina(jg);
        distancia_atributo[8] = getValor(jgfrente) - getValor(jg);
		 
		 if (strcmp(getSupertecnica(jgfrente),getSupertecnica(jg)) == 0){
			 distancia_atributo[9] = 0;
			 }else{
				  distancia_atributo[9] = 1;
				 }		 
		 for (int i = 0; i !=10; i++){
			 sum = sum + pow(distancia_atributo[i],2.0);
			 }
			 
		 distancia = sqrt(sum);
		 
		 sum = 0.0;
		 
		  if (rellenar < k){ // aqui vamos a rellenar los k primeros, estos no hace falta comparar cual es mas grande y asi porque es inutil y asi rellenamos hasta tener vecinos al completo
				 vec[rellenar].distancia = distancia;
				 
				 vec[rellenar].clase[0] = cn.ini->jg.clase[0];
				 vec[rellenar].clase[1] = cn.ini->jg.clase[1];
			 }
			 rellenar = rellenar + 1;
			 
		 if (distancia != 0 && rellenar > k ){ // cuando la ya este rellenado vecinos con los primeros K ejemplos entonces empezamos a comparar
			 
			 for (int w = 0; w < k; w++){ // aqui vamos a recorrer todos los vecinos mientras los comparamos con ellos mismos para encontar la posicion donde vamos a sustituir si hay una distancia menor
				 
				 if (max < vec[w].distancia ){
					 
					 max = vec[w].distancia;
					 
					 pos = w;
				 }
			 }
			 
			 
			for (int p = 0; p < k; p++){ // aqui vamos a recorrer todos los vecinos mientras los comparamos con ellos mismos para encontar la posicion donde vamos a sustituir si hay una distancia menor
					 
					 
				 }
			 if ( max > distancia){ // si la distancia calculada es menor que la DISTANCIA MAXIMA de los vecinos, la sustituimos
				 
				 vec[pos].distancia = distancia;
				 max = vec[pos].distancia = distancia;
				 
				 vec[pos].clase[0] = cn.ini->jg.clase[0];
				 vec[pos].clase[1] = cn.ini->jg.clase[1];
				 
				 }
			 	
		}
		avanzaSigCola(&cn);
		
			
		}
	
	return *vec;
}




tipoCola algoritmo_wilson(tipoCola c_wilson,int k,vecino vecinosk [k],jugador jg){
	int contador_clase[4];
	for (int a = 0; a < 4; a++){
		contador_clase[a] = 0;
		}	
	for (int z = 0; z < k; z++){
		
		if (vecinosk[z].clase[0] == 'G' && vecinosk[z].clase[1] == 'K'){
			contador_clase[0] = contador_clase [0] + 1;
		}
		else if (vecinosk[z].clase[0] == 'D' && vecinosk[z].clase[1] == 'F'){
			contador_clase[1] = contador_clase[1] + 1;
		}
		else if (vecinosk[z].clase[0] == 'M' && vecinosk[z].clase[1] == 'F'){
			contador_clase [2] = contador_clase [2] + 1;
		}
		else if (vecinosk[z].clase[0] == 'F' && vecinosk[z].clase[1] == 'W'){
			contador_clase[3]= contador_clase[3] + 1;
		}
	
	}
	
	
	if (contador_clase[0] > contador_clase[1] && contador_clase[0] > contador_clase[2] && contador_clase[0] > contador_clase[3]){
			if (jg.clase[0] == 'G' && jg.clase [1] == 'K'){
				encolarJugador(&c_wilson,jg);
				}
		}
	if (contador_clase[1] > contador_clase[0] && contador_clase[1] > contador_clase[2] && contador_clase[1] > contador_clase[3]){
			if (jg.clase[0] == 'D' && jg.clase [1] == 'F'){
				encolarJugador(&c_wilson,jg);
				}
		}	
	if (contador_clase[2] > contador_clase[1] && contador_clase[2] > contador_clase[0] && contador_clase[2] > contador_clase[3]){
			if (jg.clase[0] == 'M' && jg.clase [1] == 'F'){
				encolarJugador(&c_wilson,jg);
				}
		}	
	if (contador_clase[3] > contador_clase[1] && contador_clase[3] > contador_clase[2] && contador_clase[3] > contador_clase[0]){
			if (jg.clase[0] == 'F' && jg.clase [1] == 'W'){
				encolarJugador(&c_wilson,jg);
				}
		}				
	return c_wilson;
}

	
	


