#include <math.h>


typedef struct Vecino{
 	 float distancia;
     	 char clase [2];
     
     	 }vecino;
jugador crearjugador ();
tipoCola normalizar (tipoCola c, tipoMaxMin mm);

int precision (tipoCola cn, jugador jg);
vecino kdistancias (tipoCola cn,jugador jg, int k, vecino vec [k]);
tipoCola algoritmo_wilson(tipoCola c_wilson,int k,vecino vec [k],jugador jgfrente);





