Se proporciona un make para facilitar la compilacion.
Adicional.c es el codigo que hemos usado durante todo el proceso, pero con el menu.c todo funciona correctamente

