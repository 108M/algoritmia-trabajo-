#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "colaMaxMin.h"


void nuevaColaMm(tipoColaMaxMin *c) {
    c->ini = NULL;
	c->fin = NULL;
}
//inicia la cola con los elementos del primer jugador
void iniciarColaMm(tipoColaMaxMin *c, tipoElementoCola t [8]) {
    celdaMaxMin *aux;
    aux = (celdaMaxMin*)malloc(sizeof(celdaMaxMin));
    aux -> sig = NULL;
    for (int i = 0; i < 2; i++) {
        aux -> Mm.FP[i] = t[0];
    }

    for (int i = 0; i < 2; i++) {
        aux -> Mm.TP[i] = t[1];
    }

    for (int i = 0; i < 2; i++) {
        aux -> Mm.Patada[i] = t[2];
    }

    for (int i = 0; i < 2; i++) {
        aux -> Mm.Cuerpo[i] = t[3];
    }

    for (int i = 0; i < 2; i++) {
        aux -> Mm.Control[i] = t[4];
    }

    for (int i = 0; i < 2; i++) {
        aux -> Mm.Guardia[i] = t[5];
    }

    for (int i = 0; i < 2; i++) {
        aux -> Mm.Velocidad[i] = t[6];
    }

    for (int i = 0; i < 2; i++) {
        aux -> Mm.Estamina[i] = t[7];
    }

    for (int i = 0; i < 2; i++) {
        aux -> Mm.Valor[i] = t[8];
    }

    c->ini = aux;
    c->fin = aux;  
}

void encolarMm(tipoColaMaxMin *c, int t [8]) {
    celdaMaxMin *aux;
    aux = (celdaMaxMin*)malloc(sizeof(celdaMaxMin));
    aux -> sig = NULL;
	
	//No juzguen el éxito
	if (t[0] >= c -> ini -> Mm.FP[1]) {
		c -> fin ->Mm.FP[1] = t[0];
	}
	if (t[0] < c -> ini -> Mm.FP[0]) {
		c -> fin ->Mm.FP[0] = t[0];
	}
	
	if (t[1] >= c -> ini -> Mm.TP[1]) {
		c -> fin ->Mm.TP[1] = t[1];
	}
	if (t[1] < c -> ini -> Mm.TP[0]) {
		c -> fin ->Mm.TP[0] = t[1];
	}
	
	if (t[2] >= c -> ini -> Mm.Patada[1]) {
		c -> fin ->Mm.Patada[1] = t[2];
	}
	if (t[2] < c -> ini -> Mm.Patada[0]) {
		c -> fin ->Mm.Patada[0] = t[2];
	}
	
	if (t[3] >= c -> ini -> Mm.Cuerpo[1]) {
		c -> fin ->Mm.Cuerpo[1] = t[3];
	}
	if (t[3] < c -> ini -> Mm.Cuerpo[0]) {
		c -> fin ->Mm.Cuerpo[0] = t[3];
	}
	
	if (t[4] >= c -> ini -> Mm.Control[1]) {
		c -> fin ->Mm.Control[1] = t[4];
	}
	if (t[4] < c -> ini -> Mm.Control[0]) {
		c -> fin ->Mm.Control[0] = t[4];
	}
	
	if (t[5] >= c -> ini -> Mm.Guardia[1]) {
		c -> fin ->Mm.Guardia[1] = t[5];
	}
	if (t[5] < c -> ini -> Mm.Guardia[0]) {
		c -> fin ->Mm.Guardia[0] = t[5];
	}
	
	if (t[6] >= c -> ini -> Mm.Velocidad[1]) {
		c -> fin ->Mm.Velocidad[1] = t[6];
	}
	if (t[6] < c -> ini -> Mm.Velocidad[0]) {
		c -> fin ->Mm.Velocidad[0] = t[6];
	}
	
	if (t[7] >= c -> ini -> Mm.Estamina[1]) {
		c -> fin ->Mm.Estamina[1] = t[7];
	}
	if (t[7] < c -> ini -> Mm.Estamina[0]) {
		c -> fin ->Mm.Estamina[0] = t[7];
	}
	
	if (t[8] >= c -> ini -> Mm.Valor[1]) {
		c -> fin ->Mm.Valor[1] = t[8];
	}
	if (t[8] < c -> ini -> Mm.Valor[0]) {
		c -> fin ->Mm.Valor[0] = t[8];
	}
	
	c -> fin -> sig = aux;
    c->fin = aux;
}

void desencolarMm(tipoColaMaxMin *c) {
    celdaMaxMin *aux;
	
	if(esNulaColaMm(*c)){
		printf("No se puede desencolar en una cola vacia");
	}
	else{
		aux = c->ini;	
		c->ini = c->ini->sig;
		if(esNulaColaMm(*c)){
			c->fin = NULL;
		}
	}
	free(aux);
}
/*
MaxMin frenteMm(tipoColaMaxMin c) {
    if(esNulaCola(c)){
		printf("No hay primero en una cola vacia");
	}
	else{
		return (c.ini)->Mm;
	}
}
*/
bool esNulaColaMm(tipoColaMaxMin c) {
    return (c.ini == NULL);
}

