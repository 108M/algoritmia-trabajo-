#include <stdbool.h>

typedef int tipoElementoCola;

typedef struct MaxMin{
    tipoElementoCola FP[1];
	tipoElementoCola TP[1];
    tipoElementoCola Patada[1];
	tipoElementoCola Cuerpo[1];
	tipoElementoCola Control[1];
	tipoElementoCola Guardia[1];
	tipoElementoCola Velocidad[1];
	tipoElementoCola Estamina[1];
	tipoElementoCola Valor[1];
}MaxMin;


typedef struct celdaMaxMin{
 	MaxMin Mm; 
 	struct celdaMaxMin *sig;
 } celdaMaxMin; 

typedef struct tipoMaxMin{
	celdaMaxMin* ini;
	celdaMaxMin* fin;
}tipoColaMaxMin;

void nuevaColaMm(tipoColaMaxMin *);

void iniciarColaMm(tipoColaMaxMin *, tipoElementoCola t [8]);

void encolarMm(tipoColaMaxMin *, tipoElementoCola t [8]);

void desencolarMm(tipoColaMaxMin *);

MaxMin frenteMm(tipoColaMaxMin);

bool esNulaColaMm(tipoColaMaxMin);
