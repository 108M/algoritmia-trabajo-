#include<ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include "colaMaxMin.h"
int main(){
	tipoColaMaxMin c;
    char nombre [50], basura;
    int a,i,aux,elem,j;
    
    MaxMin Mm;

    tipoElementoCola t[8];
    FILE *f;
    
    j = 1;
    i = -1;
    nuevaColaMm(&c);
    
    printf( "Introduzca el nombre del fichero a leer: \n");
    scanf (" %s", nombre);
    f=fopen(nombre,"r");
    
    while (!feof(f))
    {
        if (fscanf (f,"%d",&a) == 1 && basura == ','){
            aux = a;
            i = i + 1;
           t[i] = aux ;
           //printf("%d ",t[i]);
            if ( i == 8){
                if (j == 1) {
                    iniciarColaMm(&c, t);
                    printf("%d \n", c.ini->Mm.FP[0]);

                    printf("%d \n", c.ini->Mm.Valor[1]);
                    j = 2;
                    i = -1;
                }
                else {
					printf("asdf");
                    encolarMm(&c,t);
                    i = -1;
           
                }
            }
            
        }else{

            basura=fgetc(f);   
        }
        
        printf("\n");
        fclose;
        
    }
    //
    printf("%d \n", c.ini->Mm.FP[0]);
    printf("%d \n", c.ini->Mm.Valor[0]);

    return 0;
}
