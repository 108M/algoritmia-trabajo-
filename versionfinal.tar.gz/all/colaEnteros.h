#include <stdbool.h>

typedef float tipoElementoCola;

 typedef struct Jugador{
 	 tipoElementoCola FP;
     tipoElementoCola TP;
     tipoElementoCola Patada;
	 tipoElementoCola Cuerpo;
	 tipoElementoCola Control;
	 tipoElementoCola Guardia;
	 tipoElementoCola Velocidad;
	 tipoElementoCola Estamina;
	 tipoElementoCola Valor;
     	 char clase [2];
     	 char supertecnica [100]; 
     	 }jugador;
 
typedef struct celdaC{
 	jugador jg; 
 	struct celdaC *sig;
 } celdaCola; 
 
typedef struct tipoC{
	celdaCola* ini;
	celdaCola* fin;
}tipoCola;

void nuevaCola(tipoCola *);

void encolar(tipoCola *, float jugador [8], char cl [2], char* super);

void encolarJugador(tipoCola *, jugador );

void desencolar(tipoCola *);

jugador frente(tipoCola);

bool esNulaCola(tipoCola);
