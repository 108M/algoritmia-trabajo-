#include<ctype.h>
#include <stdlib.h>
#include <stdio.h>

#include "colaEnteros.h"
#include "maxMin.h"
#include "normalizar.h"

int main() {
    
    //LEER PARA OBTENER LOS JUGADORES
    char nombre [50], basura,anterior,clase [2],super[100];
    int a,i,y,aux,elem;
    
    jugador primero, jugador1;
    tipoMaxMin mm;
    nuevoMm(&mm);
    float t[9];
    float distancia = 0.0;
    FILE *f;
    
    y = 0 ;
    i = -1;
    int j = 1;
    
    tipoCola c;
    nuevaCola(&c);
    
    tipoCola cn; //cola normalizada 
    nuevaCola(&cn);
    
    printf( "Introduzca el nombre del fichero a leer: \n");
    scanf (" %s", nombre);
    f=fopen(nombre,"r");
    
    printf("Leyendo jugadores...\n");
    
    while (!feof(f))
    {
        if (fscanf (f,"%d",&a) == 1 && basura == ','){
            aux = a;
            i = i + 1;
           t[i] = aux ;
           //printf("%f ",t[i]);
            if ( i == 8){
				//printf("\n");
				if (j == 1) {
                    //iniciar maxmin con los primeros valores
                    iniciarMm(&mm, t);
                    
                    j = 2;
                    i = -1;
                } else {
					//printf("asdf");
                    compararMmYt(&mm, t);
                    i = -1;
               }
               
               
               basura = fgetc(f); //leer la coma despues del ultimo numero
               basura = fgetc(f);
               
               while ( basura != ','){
				   super[y] = basura;
				   basura = fgetc(f);
				   y = y + 1;
				   }
			 y = 0;
               encolar(&c,t,clase, super);
               
               i = -1;
            }
            
        }else{
            anterior = basura;
            basura=fgetc(f);
            
            if (anterior == 'G' && basura == 'K') {
                //printf("leo GK");
                clase [0] = 'G';
                clase [1] = 'K';
            }
            else if(anterior == 'D' && basura == 'F') {
                //printf("leo DF");
                 clase [0] = 'D';
                 clase [1] = 'F';
            }
            else if (anterior == 'M' && basura == 'F') {
                //printf("leo MF");
                 clase [0] = 'M';
                 clase [1] = 'F';
            }
            else if(anterior == 'F' && basura == 'W') {
                //printf("leo FW");
                 clase [0] = 'F';
                 clase [1] = 'W';
				}
			}
        
       
                
        }
        
        
        
 
//METEMOS NUESTRO JUGADOR EN LA ULTIMA POSICION DE LA COLA
	jugador1 = crearjugador();
    encolarJugador(&c,jugador1);
    
    
    
    cn = normalizar(cn,c,mm);
    
 
    
    
 
	tipoCola aux_cola,cn2; // creo cn2 porque sino no podemos calcular los vecinos 
	nuevaCola(&aux_cola);
	nuevaCola(&cn2);
	aux_cola = cn;
	cn2 = cn;
	jugador jg_aux;
	int metido = 0;
	float cont = 0, cantidad = 0, porcentaje = 0.0;
	;
	while (aux_cola.ini!= NULL){
		
		jg_aux = aux_cola.ini-> jg;
		
		aux_cola.ini = aux_cola.ini->sig;
		
		cont = cont + precision(cn,jg_aux);
		
		cantidad = cantidad + 1;
		metido = metido + 1;
		}
	porcentaje = (cont/ cantidad) * 100;
	printf(" hay %f jugadores \n",cantidad);
	printf (" he acertado %f \n",cont);
	printf("el porcentaje de acierto es %f \n", porcentaje); 
	
	
	int k = 200;
	int contador [4];
	
	vecino vecinosk [k];
	
	
	kdistancias(cn2,k,vecinosk);
	for (int a = 0; a < 4; a++){
		contador[a] = 0;
		}	
	for (int z = 0; z < k; z++){
		//printf("la clase del %d vecino es %c %c y su distancia es %f \n",z,vecinosk[z].clase[0],vecinosk[z].clase[1],vecinosk[z].distancia);
		if (vecinosk[z].clase[0] == 'G' && vecinosk[z].clase[1] == 'K'){
			contador [0] = contador [0] + 1;
		}
		else if (vecinosk[z].clase[0] == 'D' && vecinosk[z].clase[1] == 'F'){
			contador [1] = contador [1] + 1;
		}
		else if (vecinosk[z].clase[0] == 'M' && vecinosk[z].clase[1] == 'F'){
			contador [2] = contador [2] + 1;
		}
		else if (vecinosk[z].clase[0] == 'F' && vecinosk[z].clase[1] == 'W'){
			contador [3]= contador [3] + 1;
		}
	
	}
	printf("hay %d porteros,%d defensas,%d medios,%d delanteros  \n",contador [0],contador [1],contador [2],contador [3] );
	
	if (contador[0] > contador[1] && contador[0] > contador[2] && contador[0] > contador[3]){
			printf("La clase predicha es GK\n");
		}
	if (contador[1] > contador[0] && contador[1] > contador[2] && contador[1] > contador[3]){
			printf("La clase predicha es DF \n");
		}	
	if (contador[2] > contador[1] && contador[2] > contador[0] && contador[2] > contador[3]){
			printf("La clase predicha es MF\n");
		}	
	if (contador[3] > contador[1] && contador[3] > contador[2] && contador[3] > contador[0]){
			printf("La clase predicha es FW\n");
		}				
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
    return 0;
}
