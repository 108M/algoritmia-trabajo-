#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "colaEnteros.h"

void nuevaCola(tipoCola *c){
	//printf("se crea la cola \n");
	c->ini = NULL;
	c->fin = NULL;
}

void errorCola(char s[]){
	printf("\n\n\nERROR en el modulo Colas: %s \n", s);
}


void encolar(tipoCola *c, float t [8], char cl [2], char* super){
	celdaCola *n;
	n = (celdaCola*)malloc(sizeof(celdaCola));
    
    //metemos datos del jugador
    n->jg.FP = t[0];
    n->jg.TP = t[1];
    n->jg.Patada = t[2];
    n->jg.Cuerpo = t[3];
    n->jg.Control = t[4];
    n->jg.Guardia = t[5];
    n->jg.Velocidad = t[6];
    n->jg.Estamina = t[7];
    n->jg.Valor = t[8];
    n->jg.clase[0] = cl [0];
    n->jg.clase[1] = cl [1];
    strcpy(n->jg.supertecnica, super);
    
	printf(" primera supertecnia es %s \n", n->jg.supertecnica);	
		
    
    // siguiente nulo
    n->sig = NULL;
    
	if(esNulaCola(*c)){
	
		c->ini = n;
	}
	else{
		c->fin->sig = n;
	}
	c->fin = n;
}

void encolarJugador(tipoCola *c, jugador jg){
    celdaCola *n;
	n = (celdaCola*)malloc(sizeof(celdaCola));
    n->jg = jg;
    n->sig = NULL;
    
    if(esNulaCola(*c)){
	
		c->ini = n;
	}
	else{
		c->fin->sig = n;
	}
	c->fin = n;
}

void desencolar(tipoCola *c){
	celdaCola *aux;
	
	if(esNulaCola(*c)){
		errorCola("No se puede desencolar en una cola vacia");
	}
	else{
		aux = c->ini;	
		c->ini = c->ini->sig;
		if(esNulaCola(*c)){
			c->fin = NULL;
		}
	}
	free(aux);
}
jugador frente (tipoCola c){
	if(esNulaCola(c)){
		errorCola("No hay primero en una cola vacia");
	}
	else{
		return (c.ini)->jg ;
	}
}

bool esNulaCola(tipoCola c){
	return (c.ini == NULL);
}


void  leerSupertecnia (){
	
	
	
	}

