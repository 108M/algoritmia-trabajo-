#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include "colaEnteros.h"
#include "maxMin.h"
#include <string.h>



jugador crearjugador (){
	jugador jg;
	printf("Introduzca los datos del jugador que piensa crear: \n");
	printf("Introduzca los puntos fisicos (FP): \n");
	scanf("%f", &jg.FP);
	printf("Introduzca los puntos de tecnica (TP): \n");
	scanf("%f", &jg.TP);
	printf("Introduzca los puntos de Patada (FP): \n");
	scanf("%f", &jg.Patada);
	printf("Introduzca los puntos de cuerpo : \n");
	scanf("%f", &jg.Cuerpo);
	printf("Introduzca los puntos de control: \n");
	scanf("%f", &jg.Control);
	printf("Introduzca los puntos de guardia : \n");
	scanf("%f", &jg.Guardia);
	printf("Introduzca los puntos de velocidad : \n");
	scanf("%f", &jg.Velocidad);
	printf("Introduzca los puntos de estamina: \n");
	scanf("%f", &jg.Estamina);
	printf("Introduzca los puntos de valor: \n");
	scanf("%f", &jg.Valor);
	printf("Introduzca su primera supertecnica: \n");
	scanf(" %s", jg.supertecnica);
	printf("JUGADOR CREADO CON EXITO \n");
	return jg;
	
	}

tipoCola normalizar (tipoCola cn, tipoCola c,tipoMaxMin mm ){
	//APLICAR NORMALIZACION
    printf("El maximo FP es %f y el minimo FP es %f\n", mm->FP[1], mm->FP[0]);
    printf("El maximo Valor es %f y el minimo Valor es %f\n", mm->Valor[1], mm->Valor[0]);
    
    while(!esNulaCola(c)){
        //jugador
        jugador jg;
        jg = frente (c);
        desencolar(&c);
        
        //normalizar jugador
        jg.FP = (jg.FP - devuelveMinimo(0, mm))/(devuelveMaximo(0, mm)- devuelveMinimo(0, mm));
        jg.TP = (jg.TP - devuelveMinimo(1, mm))/(devuelveMaximo(1, mm)- devuelveMinimo(1, mm));
        jg.Patada = (jg.Patada - devuelveMinimo(2, mm))/(devuelveMaximo(2, mm)- devuelveMinimo(2, mm));
        jg.Cuerpo = (jg.Cuerpo - devuelveMinimo(3, mm))/(devuelveMaximo(3, mm)- devuelveMinimo(3, mm));
        jg.Control = (jg.Control - devuelveMinimo(4, mm))/(devuelveMaximo(4, mm)- devuelveMinimo(4, mm));
        jg.Guardia = (jg.Guardia - devuelveMinimo(5, mm))/(devuelveMaximo(5, mm)- devuelveMinimo(5, mm));
        jg.Velocidad = (jg.Velocidad - devuelveMinimo(6, mm))/(devuelveMaximo(6, mm)- devuelveMinimo(6, mm));
        jg.Estamina = (jg.Estamina - devuelveMinimo(7, mm))/(devuelveMaximo(7, mm)- devuelveMinimo(7, mm));
        jg.Valor = (jg.Valor - devuelveMinimo(8, mm))/(devuelveMaximo(8, mm)- devuelveMinimo(8, mm));
        
        
        //jg.FP = (jg.FP - devuelveMinimo(0, mm))/(devuelveMaximo(0, mm)- devuelveMinimo(0, mm));
        
        //encolo normalizado
        encolarJugador(&cn, jg);
        
        
    }
   return cn;
	
}

float calcular_distancia (tipoCola cn){
	float sum = 0.0;
	float distancia = 0.0;
	float minimo = 1000.0;
	float distancia_atributo [9];
	while(cn.ini->sig != NULL){
		printf("normalizado FP primero %f \n", cn.ini->jg.F P);
		printf("normalizado TP primero %f \n", cn.ini->jg.TP);
		 distancia_atributo[0] = cn.ini->jg.FP - cn.fin->jg.FP;
		 printf("distancia FP %f \n",distancia_atributo[0]);
		 distancia_atributo[1] = cn.ini->jg.TP - cn.fin->jg.TP;
		 distancia_atributo[2] = cn.ini->jg.Patada - cn.fin->jg.Patada;
		 distancia_atributo[3] = cn.ini->jg.Cuerpo - cn.fin->jg.Cuerpo;
		 distancia_atributo[4] = cn.ini->jg.Control - cn.fin->jg.Control;
		 distancia_atributo[5] = cn.ini->jg.Guardia - cn.fin->jg.Guardia;
		 distancia_atributo[6] = cn.ini->jg.Velocidad - cn.fin->jg.Velocidad;
		 distancia_atributo[7] = cn.ini->jg.Estamina - cn.fin->jg.Estamina;
		 distancia_atributo[8] = cn.ini->jg.Valor - cn.fin->jg.Valor;
		 if (strcmp(cn.ini->jg.supertecnica,cn.fin->jg.supertecnica) == 0){
			 distancia_atributo[9] = 0;
			 
			 }else{
				  distancia_atributo[9] = 1;
				 }
		 for (int i = 0; i !=10; i++){
			 sum = sum + pow(distancia_atributo[i],2.0);
			 printf(" la suma es %f\n",sum);
			 }
			 printf(" la suma es %f\n",sum);
		 distancia = sqrt(sum);
		 sum = 0.0;
		 printf(" la distancia es %f \n",distancia);
		 if (minimo >= distancia){
			 minimo = distancia;
			 cn.fin->jg.clase[0] = cn.ini->jg.clase[0];
			 cn.fin->jg.clase[1] = cn.ini->jg.clase[1];
			printf (" %c" " %c \n", cn.fin->jg.clase[0],cn.fin->jg.clase[1]);
			}
		cn.ini = cn.ini->sig;
			
	}
	return distancia;
}
